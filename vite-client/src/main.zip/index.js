const express = require('express');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
require('dotenv').config();
const { Pool } = require('pg');

const app = express();
app.use(cors());
app.use(express.json());

// Serve uploaded images
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// PostgreSQL connection setup
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

// Ensure the uploads directory exists
const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir);
}

// Configure Multer storage
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    const uniqueName = `${Date.now()}-${Math.round(Math.random() * 1E9)}${path.extname(file.originalname)}`;
    cb(null, uniqueName);
  }
});
const upload = multer({ storage });

// POST /api/upload: handle card metadata and image uploads
app.post('/api/upload', upload.array('images', 6), async (req, res) => {
  try {
    const {
      cardName,
      cardSet,
      condition,
      isFoil,
      language,
      tradeValue
    } = req.body;

    const imageFilenames = req.files.map(file => path.join('uploads', file.filename));

    const result = await pool.query(
      `INSERT INTO cards
        (user_id, card_name, set_name, expansion, condition, foil, language, trade_value, image_urls)
       VALUES
        ($1, $2, $3, $4, $5, $6, $7, $8, $9)
       RETURNING *`,
      [
        1, // Hardcoded user_id for now
        cardName,
        cardSet,
        '', // expansion (empty for now, unless you plan to include it)
        condition,
        isFoil === 'true',
        language,
        parseFloat(tradeValue),
        imageFilenames
      ]
    );

    console.log('[✅] Card saved to DB:', result.rows[0]);

    res.json({
      success: true,
      message: 'Card uploaded and saved to database!',
      data: result.rows[0]
    });

  } catch (error) {
    console.error('[❌] Upload error:', error);
    res.status(500).json({ success: false, message: 'Upload failed.' });
  }
});

// GET /api/inventory/:userId — Fetch all cards by user ID
app.get('/api/inventory/:userId', async (req, res) => {
  const { userId } = req.params;
  try {
    const result = await pool.query(
      'SELECT * FROM cards WHERE user_id = $1 ORDER BY created_at DESC',
      [userId]
    );
    res.json(result.rows);
  } catch (err) {
    console.error('[❌] Inventory fetch error:', err);
    res.status(500).json({ error: 'Failed to fetch inventory' });
  }
});

// Start the server
const PORT = 5000;
app.listen(PORT, () => {
  console.log(`✅ Server running at http://localhost:${PORT}`);
});
