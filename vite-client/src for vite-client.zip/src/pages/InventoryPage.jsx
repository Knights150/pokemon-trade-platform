import React, { useEffect, useState } from 'react';
import axios from 'axios';

function InventoryPage() {
  const [cards, setCards] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/api/inventory/1') // Replace with dynamic userId later
      .then(res => setCards(res.data))
      .catch(err => console.error('Inventory fetch failed:', err));
  }, []);

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">Your Inventory</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {cards.map(card => (
          <div key={card.id} className="bg-white rounded shadow p-4 space-y-2">
            <img
              src={`http://localhost:5000/${card.image_urls[0].replace(/\\/g, '/')}`}
              alt={card.card_name}
              className="w-full h-auto rounded"
            />
            <div>
              <h3 className="font-semibold">{card.card_name}</h3>
              <p className="text-sm text-gray-600">{card.set_name}</p>
              <p className="text-sm">Condition: {card.condition}</p>
              <p className="text-sm">Language: {card.language}</p>
              <p className="text-sm">Trade Value: ${card.trade_value}</p>
              <p className="text-sm font-medium text-green-600">
                {card.tradeable ? 'Tradeable' : 'Not for Trade'}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default InventoryPage;
